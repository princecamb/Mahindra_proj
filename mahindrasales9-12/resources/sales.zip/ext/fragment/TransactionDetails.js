sap.ui.define([],function(){"use strict";return{predefinedMethod:function(){},formatter:{formatText:function(t){return t||"_"}}}});
//# sourceMappingURL=TransactionDetails.js.map